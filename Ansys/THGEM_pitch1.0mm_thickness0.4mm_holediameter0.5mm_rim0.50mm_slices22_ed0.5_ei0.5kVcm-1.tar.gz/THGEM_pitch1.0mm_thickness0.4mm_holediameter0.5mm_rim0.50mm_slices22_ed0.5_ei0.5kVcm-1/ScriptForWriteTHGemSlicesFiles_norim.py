#!/usr/bin/env python

import os
import sys
import math
import numbers

def matchVoltage(check_value, check_vector):
	for value in check_vector:
		if int(check_value)==value:
			return True
			break
	return False
			
pitch=float(sys.argv[1])
thickness=float(sys.argv[2])
holedia=float(sys.argv[3])
rim=float(sys.argv[4])
numberOfSlices=int(sys.argv[5])
edrift=float(sys.argv[6])
einduc=float(sys.argv[7])
#VTHGEM=float(sys.argv[2])



files_range=range(1, numberOfSlices-1)
VTHGEM=[400,450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000, 1050, 1100, 1150, 1200, 1250, 1300, 1350, 1400, 1450, 1500]
#VTHGEM=[1141]
files_range=VTHGEM+files_range

#print(files_range)

for sliceNumber in files_range:
	if (matchVoltage(sliceNumber,VTHGEM)):
		filename='thgemcut'+str(sliceNumber)+'V.ansys'
	else:
		filename='thgemcut_slice'+str(sliceNumber)+'.ansys'
	file = open(filename,'w')
	file.write('\n\
FINISH\n\
/CLEAR,START\n\
/PREP7\n\
\n\
! Define surface charges\n\
\n\
*DIM,qsurf,ARRAY,'+str(numberOfSlices-2)+'\n\
*DIM,rimsurf,ARRAY,2\n\
!Slices are numbered from 1->negative z to n -> positive z\n\
\n\
*do, i, 1, '+str(numberOfSlices-2)+'\n\
qsurf(i) = 0\n\
*enddo\n\
\n')
	if (matchVoltage(sliceNumber,VTHGEM)):
		file.write('\n')
	else:
		file.write('qsurf('+str(sliceNumber)+') = 1\n')
	file.write('! 400 V, after 15x1e5\n\
! No polynomial elements\n\
/PMETH,OFF,1\n\
! Set electric preferences\n\
KEYW,PR_ELMAG,1  ! What is meant by this?\n\
KEYW,MAGELC,1    ! What is meant by this?\n\
\n\
! Select element\n\
ET,1,SOLID123\n\
\n\
! Material properties\n\
MP,PERX,1,1e10   ! Metal Permittivity\n\
MP,RSVX,1,0.0    ! Metal Resistivity\n\
MP,PERX,2,1.0    ! Gas Permittivity\n\
MP,PERX,3,3.9    ! Permittivity of kapton\n\
\n\
! Construct the GEM\n\
pitch =  '+str(pitch)+'   ! Distance between holes, in mm\n\
kapton = '+str(thickness)+'   ! Thickness of the kapton layer, in mm\n\
metal =  0.005   ! Thickness of the metal layers, in mm\n\
outdia = '+str(holedia)+'   ! Hole outer diameter, in mm\n\
middia = '+str(holedia)+'   ! Hole diameter in the centre, in mm\n\
drift =  4.0     ! Position of the drift plane in mm\n\
induct = -2.0    ! Position of the induction plane in mm\n\
rim =    '+str(rim)+'   ! Rim diameter, in mm\n')
	if (matchVoltage(sliceNumber,VTHGEM)):
		file.write('v = '+str(sliceNumber)+'     ! Voltage difference across the THGEM\n\
e_d = '+str(edrift*1000/10)+'        ! Electric field between drift plane and upper metal (abs,V/mm)\n\
e_i = '+str(einduc*1000/10)+'        ! Electric field between lower metal and inductive plane (abs,V/mm)\n')
	else:
		file.write('v = 0     ! Voltage difference across the THGEM\n\
e_d = 0        ! Electric field between drift plane and upper metal (abs,V/mm)\n\
e_i = 0        ! Electric field between lower metal and inductive plane (abs,V/mm)\n')
	file.write('unit = 1000      ! Units: 1000 for mm, 100 for cm, 1 for m\n\
pi = 3.14159265  ! pi\n\
qe = 1.60217646e-19      ! Electron charge [C]\n\
n = '+str(numberOfSlices-2)+'         ! Number of slices\n\
\n\
! Eistance between drift plane and upper metal (abs,mm)\n\
distDriftUpperMetal = drift-kapton/2-metal\n\
! Distance between lower metal and inductive plane (abs,mm)\n\
distInductLowerMetal = -1*induct-kapton/2-metal\n\
\n\
! Make the plastic (1-n), lower metal (n+1), upper metal (n+2) and gas (n+3)\n\
! Kapton layers\n\
*do, i, 1, n\n\
BLOCK, 0, pitch/2, 0, sqrt(3)*pitch/2, -kapton/2+(i-1)*kapton/n,  -kapton/2+(i)*kapton/n\n\
*enddo\n\
!Metal layers\n\
\n\
BLOCK, 0, pitch/2, 0, sqrt(3)*pitch/2, -kapton/2, -kapton/2-metal  !n+1\n\
BLOCK, 0, pitch/2, 0, sqrt(3)*pitch/2, kapton/2, kapton/2+metal	 !n+2\n\
BLOCK, 0, pitch/2, 0, sqrt(3)*pitch/2, induct, drift			 !n+3\n\
\n\
! OK ate aqui\n\
\n\
! Make the cut-out pieces: n+4 - n+7\n\
! Make the biconical section\n\
CONE, outdia/2, middia/2, -kapton/2,   0, 0, 360			!n+4\n\
CONE, middia/2, outdia/2, 0, kapton/2, 0, 0, 360			!n+5\n\
! Creation of a metal rim on top and bottom of the cones \n\
WPOFFS, 0, 0, kapton/2\n\
CYL4,   0, 0, rim/2, ,,, metal						!n+6	\n\
WPOFFS, 0, 0, -kapton\n\
CYL4,   0, 0, rim/2, ,,, -metal						!n+7\n\
WPOFFS, 0, 0, kapton/2\n\
\n\
VADD, n+4, n+5, n+6, n+7   ! Makes volume n+8 and frees n+4 - n+7\n\
\n\
WPOFFS, pitch/2, sqrt(3)*pitch/2, 0\n\
CONE, outdia/2, middia/2, -kapton/2,   0, 0, 360		!n+4\n\
CONE, middia/2, outdia/2, 0, kapton/2, 0, 0, 360		!n+5\n\
WPOFFS, 0, 0, kapton/2\n\
CYL4,   0, 0, rim/2, ,,, metal					!n+6\n\
WPOFFS, 0, 0, -kapton\n\
CYL4,   0, 0, rim/2, ,,, -metal					!n+7\n\
WPOFFS, 0, 0, kapton/2\n\
\n\
VADD, n+4, n+5, n+6, n+7 ! Makes volume n+9 and frees n+4 - n+7\n\
\n\
! Subtract from the kapton layers (is i, becomes i)\n\
*do, i, 1, n\n\
VSBV,  i,   n+8, , , KEEP   ! i   -> n+4\n\
VSBV,  n+4, n+9, , , KEEP   ! n+4 -> i\n\
*enddo\n\
! Subtract from the lower metal (is n+1, becomes n+1)\n\
VSBV,  n+1, n+8, , , KEEP   ! n+1 -> n+4\n\
VSBV,  n+4, n+9, , , KEEP   ! n+4 -> n+1\n\
! Subtract from the upper metal (is n+2, becomes n+2)\n\
VSBV,  n+2, n+8, , , KEEP   ! n+2 -> n+4\n\
VSBV,  n+4, n+9, , , KEEP   ! n+4 -> n+2\n\
\n\
! Delete the holes\n\
VDEL, n+8, n+9\n\
\n\
! Subtract the kapton and metal from the gas (is n+3, becomes n+?)\n\
VSBV,  n+3, n+1, , , KEEP   ! n+3 -> n+4\n\
VSBV,  n+4, n+2, , , KEEP   ! n+4 -> n+3\n\
*do, i, 1, n,2\n\
VSBV,  n+3, i  , , , KEEP   ! n+3 -> n+4\n\
VSBV,  n+4, i+1, , , KEEP   ! n+4 -> n+3\n\
*enddo\n\
\n\
! Glue everything together\n\
VGLUE, ALL\n\
\n\
!AQUI\n\
VSEL, ALL\n\
VPLOT\n\
VSEL, ALL\n\
VSEL, S,,,1\n\
VSEL, A,,,n+5\n\
*do, i, 1, n-2\n\
VSEL, A,,,n+4+2+(i)\n\
*enddo\n\
VPLOT\n\
VATT, 3\n\
\n\
\n\
!8 e o bottom metal\n\
! 7 e o gas\n\
!10 e o top metal\n\
\n\
\n\
VSEL, ALL\n\
VSEL, S,,,n+4\n\
VSEL, A,,,n+4+2\n\
VPLOT\n\
VATT, 1\n\
\n\
VSEL, ALL\n\
VSEL, S,,,n+3\n\
VPLOT\n\
VATT, 2\n\
\n\
SELTOL\n\
VSEL,ALL\n\
! Voltage boundaries on the drift and induction plane\n\
ASEL, S, LOC, Z, drift\n\
DA, ALL, VOLT, -v/2 - e_d*distDriftUpperMetal\n\
ASEL, S, LOC, Z, induct\n\
DA, ALL, VOLT, v/2 + e_i*distInductLowerMetal\n\
\n\
\n\
! Voltage boundary condition on the lower metal\n\
VSEL, S, LOC, Z, kapton/2+metal/2\n\
ASLV, S\n\
DA, ALL, VOLT, -v/2\n\
! Voltage boundary condition on the upper metal\n\
VSEL, S, LOC, Z, -kapton/2-metal/2\n\
ASLV, S\n\
DA, ALL, VOLT, v/2\n\
\n\
\n\
! Symmetry boundary conditions on the sides\n\
VSEL, ALL\n\
VSEL, S,,,1\n\
VSEL, A,,,n+5\n\
*do, i, 1, n-2\n\
VSEL, A,,,n+4+2+(i)\n\
*enddo\n\
ASLV, S\n\
ASEL, R, LOC, X, 0\n\
DA, ALL, SYMM\n\
ASLV, S\n\
ASEL, R, LOC, X, +pitch/2\n\
DA, ALL, SYMM\n\
ASLV, S\n\
ASEL, R, LOC, Y, 0\n\
DA, ALL, SYMM\n\
ASLV, S\n\
ASEL, R, LOC, Y, +sqrt(3)*pitch/2\n\
DA, ALL, SYMM\n\
\n\
VSEL, ALL\n\
VSEL, S,,,n+3\n\
ASLV, S\n\
ASEL, R, LOC, X, 0\n\
DA, ALL, SYMM\n\
ASLV, S\n\
ASEL, R, LOC, X, +pitch/2\n\
DA, ALL, SYMM\n\
ASLV, S\n\
ASEL, R, LOC, Y, 0\n\
DA, ALL, SYMM\n\
ASLV, S\n\
ASEL, R, LOC, Y, +sqrt(3)*pitch/2\n\
DA, ALL, SYMM\n\
\n\
! Apply charge on the inner surface\n\
\n\
!slant = sqrt(kapton**2+(outdia-middia)**2)/n\n\
*do, i, 1, n\n\
  VSEL,ALL\n\
  ASLV\n\
  ASEL,R,LOC,X,0,middia/2\n\
  ASEL,R,LOC,Y,0,middia/2\n\
  SELTOL, 0.001\n\
  ASEL,R,LOC,Z,-kapton/2+(i-1)*(kapton)/(n)+kapton/(2*n)\n\
  ASUM \n\
  *GET,SURFACE,AREA,ALL,AREA  \n\
  SFA,ALL,,CHRGS,(qsurf(i)*unit*qe)/(4*SURFACE)\n\
  \n\
  VSEL,ALL\n\
  ASLV\n\
  SELTOL, 0.01\n\
  ASEL,R,LOC,X,pitch/2-middia/2,pitch/2\n\
  ASEL,R,LOC,Y,sqrt(3)*pitch/2-middia/2,sqrt(3)*pitch/2\n\
  SELTOL, 0.001\n\
  ASEL,R,LOC,Z,-kapton/2+(i-1)*(kapton)/(n)+kapton/(2*n)\n\
  ASUM \n\
  *GET,SURFACE,AREA,ALL,AREA  \n\
  SFA,ALL,,CHRGS,(qsurf(i)*unit*qe)/(4*SURFACE)\n\
 *enddo\n\
\n\
\n\
\n\
! Meshing options\n\
VSEL, ALL\n\
ASEL, ALL\n\
VSEL, S,,,1\n\
VSEL, A,,,n+5\n\
*do, i, 1, n-2\n\
VSEL, A,,,n+4+2+(i)\n\
*enddo\n\
VSEL, A,,,n+3\n\
MSHKEY,0\n\
SMRT, 1\n\
\n\
VMESH,ALL\n\
\n\
! Solve the field\n\
/SOLU\n\
SOLVE   \n\
FINISH  \n\
\n\
! Display the solution\n\
/POST1  \n\
/EFACET,1  \n\
PLNSOL, VOLT,, 0\n\
\n\
! Write the solution to files\n')
	if (matchVoltage(sliceNumber,VTHGEM)):
		file.write('/OUTPUT, PRNSOL_'+str(sliceNumber)+'V, lis\n')
		file.write('PRNSOL\n\
/OUTPUT\n\
\n\
/OUTPUT, NLIST, lis\n\
NLIST,,,,COORD\n\
/OUTPUT\n\
\n\
/OUTPUT, ELIST, lis\n\
ELIST\n\
/OUTPUT\n\
\n\
/OUTPUT, MPLIST, lis\n\
MPLIST\n\
/OUTPUT\n\
\n\
/EXIT,NOSAV\n\
\n')

	else:
		file.write('/OUTPUT, PRNSOL_slice'+str(sliceNumber)+', lis\n')
		file.write('PRNSOL\n\
/OUTPUT\n\
\n\
/EXIT,NOSAV\n\
\n')

